Welcome! Thanks for your interest in contributing to PEP. You're **almost** in the right place. More information on how to contribute to this and all other jQuery Foundation projects is over at [contribute.jquery.org](http://contribute.jquery.org). You'll definitely want to take a look at the articles on contributing [code](http://contribute.jquery.org/code).

You may also want to take a look at our [commit & pull request guide](http://contribute.jquery.org/commits-and-pull-requests/) and [style guides](http://contribute.jquery.org/style-guide/)* for instructions on how to maintain your fork and submit your code. Before we can merge any pull request, we'll also need you to sign our [contributor license agreement](http://contribute.jquery.org/cla/).

You can find us on [IRC](http://irc.jquery.org), specifically in #pep should you have any questions. If you've never contributed to open source before, we've put together [a short guide with tips, tricks, and ideas on getting started](http://contribute.jquery.org/open-source/).

----

\* PEP follows the [jQuery JavaScript Style Guide](http://contribute.jquery.org/style-guide/js/) with the following exception:

* There are no spaces around anything that appears inside parentheses.
